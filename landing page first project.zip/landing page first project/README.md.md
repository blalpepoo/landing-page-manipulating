
# Project Title

A landing page project .


## Authors

- [Blal Mohsen](https://github.com/blalpepoo)


## Languages
. Html
. Css
. Java script
## Content 
. Make a navigation bar
. make the navigation bar responsive
.make a Li list
. highlited the section that is response to the user